<?php
/**
* @package        EasySocial
* @copyright    Copyright (C) 2010 - 2014 Stack Ideas Sdn Bhd. All rights reserved.
* @license        GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined('_JEXEC') or die('Unauthorized Access');

/**
 * Profile view for article app
 *
 * @since    1.0
 * @access    public
 */
class GuestsViewProjects extends SocialAppsView
{
    /**
     * Displays the application output in the canvas.
     *
     * @since    1.0
     * @access    public
     * @param    int        The user id that is currently being viewed.
     */
    public function display($projectId = null, $docType = null)
    {
        // Load up the project
        $project = FD::project($projectId);

        // Get the project params
        $params = $project->getParams();

        // Load up the projects model
        $model = FD::model('Projects');

        $type = FD::input()->getString('type', 'going');

        $options = array();

        if ($type === 'going') {
            $options['state'] = SOCIAL_PROJECT_GUEST_GOING;
        }

        if ($params->get('allowmaybe') && $type === 'maybe') {
            $options['state'] = SOCIAL_PROJECT_GUEST_MAYBE;
        }

        if ($params->get('allownotgoingguest') && $type === 'notgoing') {
            $options['state'] = SOCIAL_PROJECT_GUEST_NOT_GOING;
        }

        if ($project->isClosed() && $type === 'pending') {
            $options['state'] = SOCIAL_PROJECT_GUEST_PENDING;
        }

        if ($type === 'admin') {
            $options['admin'] = 1;
        }

        $this->set('type', $type);

        $guests  = $model->getGuests($project->id, $options);
        $pagination = $model->getPagination();

        $this->set('project', $project);
        $this->set('guests', $guests);

        $projectAlias = $project->getAlias();
        $appAlias = $this->app->getAlias();

        $permalinks = array(
            'going' => '',
            'notgoing' => '',
            'maybe' => '',
            'admin' => '',
            'pending' => ''
        );

        // Avoid using $filter because it is a FRoute reserved word

        foreach ($permalinks as $key => &$value) {
            $value = FRoute::projects(array(
                'layout' => 'item',
                'id' => $projectAlias,
                'appId' => $appAlias,
                'type' => $key
            ));
        }

        $this->set('permalinks', $permalinks);

        $myGuest = $project->getGuest();

        $this->set('myGuest', $myGuest);

        echo parent::display('projects/default');
    }

}
