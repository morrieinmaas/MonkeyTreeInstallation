EasySocial.require().script('site/layout/dialog').done(function($) {
    EasySocial.dialog({
        content: EasySocial.ajax('site/views/registration/request', {
            id:
        });
    });
});