<?php
/**
* @package		EasySocial
* @copyright	Copyright (C) 2010 - 2014 Stack Ideas Sdn Bhd. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* EasySocial is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
defined( '_JEXEC' ) or die( 'Unauthorized Access' );
?>
<li class="custom-filter<?php echo $fid == $filter->id ? ' active' : '';?>"
	data-sidebar-menu
	data-sidebar-item
	data-id="<?php echo $filter->id; ?>"
	data-search-filter-<?php echo $filter->id; ?>
>
	<a href="<?php echo FRoute::search( array( 'layout' => 'advanced' , 'fid' => $filter->getAlias() ) );?>"
		data-type="custom"
		data-search-filter-item
		data-id="<?php echo $filter->id; ?>"
		data-title="<?php echo $this->html( 'string.escape' , $filter->title ); ?>"
	>
		<i class="fa fa-list mr-5"></i> <?php echo $this->html( 'string.escape' , $filter->title ); ?>
	</a>
</li>
