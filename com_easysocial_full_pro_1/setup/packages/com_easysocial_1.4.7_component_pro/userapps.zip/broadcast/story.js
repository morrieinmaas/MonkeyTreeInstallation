EasySocial.require()
	.script("story/broadcast")
	.done(function($)
	{
		var plugin = story.addPlugin("broadcast");
	});
